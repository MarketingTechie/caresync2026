export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: "#0F172A",
        mint: "#00C896",
        "mint-lt": "#E6FAF5",
        sky: "#3B82F6",
        amber: "#F59E0B",
        rose: "#F43F5E",
        purple: "#8B5CF6",
        slate: "#475569",
        mist: "#F1F5F9",
      },
      fontFamily: {
        sora: ["Sora", "sans-serif"],
        serif: ["DM Serif Display", "serif"],
      },
      boxShadow: {
        card: "0 4px 24px rgba(15,23,42,.08)",
        "card-hover": "0 8px 40px rgba(15,23,42,.14)",
      },
    },
  },
  plugins: [],
};
