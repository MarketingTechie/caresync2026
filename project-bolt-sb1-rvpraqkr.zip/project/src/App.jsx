import { useState, useEffect } from "react";

const SAMPLE_MEMBERS = [
  { id: 1, name: "Papa", age: 58, relation: "Father", emoji: "👨‍🦳", color: "bg-blue-100" },
  { id: 2, name: "Mummy", age: 54, relation: "Mother", emoji: "👩", color: "bg-rose-100" },
  { id: 3, name: "Me", age: 22, relation: "Self", emoji: "🧑", color: "bg-mint-lt" },
  { id: 4, name: "Dadi", age: 78, relation: "Grandmother", emoji: "👵", color: "bg-amber-100" },
];

const SAMPLE_MEDICINES = [
  { id: 1, memberId: 1, name: "Metformin", dose: "500mg", freq: "Twice daily", time: "08:00", stock: 24, maxStock: 30, accentColor: "sky" },
  { id: 2, memberId: 1, name: "Amlodipine", dose: "5mg", freq: "Once daily", time: "09:00", stock: 8, maxStock: 30, accentColor: "purple" },
  { id: 3, memberId: 2, name: "Thyronorm", dose: "100mcg", freq: "Once daily", time: "07:00", stock: 5, maxStock: 30, accentColor: "rose" },
  { id: 4, memberId: 4, name: "Ecosprin", dose: "75mg", freq: "Once daily", time: "08:30", stock: 20, maxStock: 30, accentColor: "amber" },
];

const SAMPLE_APPOINTMENTS = [
  { id: 1, memberId: 1, title: "Diabetologist Follow-up", doctor: "Dr. Sharma", date: "2024-03-12", time: "11:00", urgency: "upcoming" },
  { id: 2, memberId: 2, title: "Thyroid Check-up", doctor: "Dr. Priya Nair", date: "2024-03-18", time: "15:00", urgency: "routine" },
  { id: 3, memberId: 4, title: "Cardiac Review", doctor: "Dr. Mehta", date: "2024-03-08", time: "10:00", urgency: "urgent" },
];

const HEALTH_TIPS = [
  "💧 Drink at least 8 glasses of water daily to stay hydrated.",
  "🚶 Take a 30-minute walk every day for better cardiovascular health.",
  "😴 Get 7-9 hours of quality sleep each night for optimal recovery.",
  "🥗 Include colorful vegetables in every meal for maximum nutrition.",
  "🧘 Practice 10 minutes of meditation daily to reduce stress.",
];

const EMERGENCY_CONTACTS = [
  { name: "Family Doctor", icon: "👨‍⚕️", bg: "bg-blue-50", color: "text-sky", phone: "tel:+911234567890" },
  { name: "Emergency 108", icon: "🚑", bg: "bg-rose-50", color: "text-rose", phone: "tel:108" },
  { name: "Cardiologist", icon: "❤️", bg: "bg-amber-50", color: "text-amber", phone: "tel:+919876543210" },
  { name: "Pharmacy", icon: "💊", bg: "bg-mint-lt", color: "text-mint", phone: "tel:+911122334455" },
];

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [members, setMembers] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [modalType, setModalType] = useState(null);
  const [toast, setToast] = useState(null);
  const [medStatus, setMedStatus] = useState({});
  const [tipIndex, setTipIndex] = useState(0);

  const [formMed, setFormMed] = useState({ memberId: 1, name: "", dose: "", freq: "Once daily", time: "", stock: "30" });
  const [formApt, setFormApt] = useState({ memberId: 1, title: "", doctor: "", date: "", time: "" });
  const [formMember, setFormMember] = useState({ name: "", age: "", relation: "" });

  useEffect(() => {
    const saved = localStorage.getItem("caresync");
    if (saved) {
      const data = JSON.parse(saved);
      setMembers(data.members || SAMPLE_MEMBERS);
      setMedicines(data.medicines || SAMPLE_MEDICINES);
      setAppointments(data.appointments || SAMPLE_APPOINTMENTS);
      setMedStatus(data.medStatus || {});
    } else {
      setMembers(SAMPLE_MEMBERS);
      setMedicines(SAMPLE_MEDICINES);
      setAppointments(SAMPLE_APPOINTMENTS);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("caresync", JSON.stringify({ members, medicines, appointments, medStatus }));
  }, [members, medicines, appointments, medStatus]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTipIndex(prev => (prev + 1) % HEALTH_TIPS.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const handleMedTaken = (medId) => {
    setMedStatus(prev => ({ ...prev, [medId]: "taken" }));
    showToast("Medicine marked as taken! ✅");
  };

  const handleMedMissed = (medId) => {
    setMedStatus(prev => ({ ...prev, [medId]: "missed" }));
    showToast("Reminder set for next dose. ⏰");
  };

  const addMedicine = () => {
    if (!formMed.name || !formMed.dose || !formMed.time) {
      showToast("Please fill in all fields", "error");
      return;
    }
    const newMed = {
      id: Date.now(),
      memberId: parseInt(formMed.memberId),
      name: formMed.name,
      dose: formMed.dose,
      freq: formMed.freq,
      time: formMed.time,
      stock: parseInt(formMed.stock) || 30,
      maxStock: 30,
      accentColor: ["sky", "purple", "rose", "amber", "mint"][medicines.length % 5],
    };
    setMedicines(prev => [...prev, newMed]);
    setFormMed({ memberId: 1, name: "", dose: "", freq: "Once daily", time: "", stock: "30" });
    setModalType(null);
    showToast(`${newMed.name} added! 💊`);
  };

  const addAppointment = () => {
    if (!formApt.title || !formApt.date) {
      showToast("Please fill in all fields", "error");
      return;
    }
    const newApt = {
      id: Date.now(),
      memberId: parseInt(formApt.memberId),
      title: formApt.title,
      doctor: formApt.doctor,
      date: formApt.date,
      time: formApt.time,
      urgency: "upcoming",
    };
    setAppointments(prev => [...prev, newApt]);
    setFormApt({ memberId: 1, title: "", doctor: "", date: "", time: "" });
    setModalType(null);
    showToast("Appointment scheduled! 📅");
  };

  const addMember = () => {
    if (!formMember.name) {
      showToast("Please enter a name", "error");
      return;
    }
    const emojis = ["🧑", "👦", "👧", "🧓", "👨", "👩"];
    const colors = ["bg-blue-100", "bg-rose-100", "bg-mint-lt", "bg-purple-100", "bg-amber-100"];
    const newMember = {
      id: Date.now(),
      name: formMember.name,
      age: formMember.age || "—",
      relation: formMember.relation || "Family",
      emoji: emojis[members.length % emojis.length],
      color: colors[members.length % colors.length],
    };
    setMembers(prev => [...prev, newMember]);
    setFormMember({ name: "", age: "", relation: "" });
    setModalType(null);
    showToast(`${newMember.name} added! 👨‍👩‍👧`);
  };

  const filteredMeds = selectedMember ? medicines.filter(m => m.memberId === selectedMember) : medicines;
  const filteredApts = selectedMember ? appointments.filter(a => a.memberId === selectedMember) : appointments;

  const lowStockMeds = medicines.filter(m => m.stock < 10);
  const takenCount = Object.values(medStatus).filter(s => s === "taken").length;
  const adherenceRate = medicines.length > 0 ? Math.round((takenCount / medicines.length) * 100) : 0;

  const getUrgencyStyle = (urgency) => {
    switch (urgency) {
      case "urgent":
        return "bg-rose-50 border-l-4 border-rose";
      case "upcoming":
        return "bg-blue-50 border-l-4 border-sky";
      default:
        return "bg-mint-lt border-l-4 border-mint";
    }
  };

  const getUrgencyBadge = (urgency) => {
    switch (urgency) {
      case "urgent":
        return "bg-rose-100 text-rose";
      case "upcoming":
        return "bg-blue-100 text-sky";
      default:
        return "bg-mint-lt text-mint";
    }
  };

  const accentColorMap = {
    sky: "text-sky from-blue-50",
    purple: "text-purple from-purple-50",
    rose: "text-rose from-rose-50",
    amber: "text-amber from-amber-50",
    mint: "text-mint from-mint-lt",
  };

  return (
    <div className="flex h-screen bg-mist font-sora overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-navy text-white flex flex-col sticky top-0 h-screen shadow-lg overflow-y-auto">
        <div className="px-6 py-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-gradient-to-br from-mint to-teal-600 rounded-lg flex items-center justify-center text-lg">
              ❤️
            </div>
            <span className="text-2xl font-serif font-bold text-white">CareSync</span>
          </div>

          <nav className="space-y-2">
            {[
              { id: "dashboard", icon: "🏠", label: "Dashboard" },
              { id: "medicines", icon: "💊", label: "Medicines" },
              { id: "appointments", icon: "📅", label: "Appointments" },
              { id: "refills", icon: "🔄", label: "Refills" },
              { id: "emergency", icon: "🚨", label: "Emergency" },
            ].map(nav => (
              <button
                key={nav.id}
                onClick={() => setPage(nav.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-smooth ${
                  page === nav.id
                    ? "bg-mint/20 text-mint"
                    : "text-gray-300 hover:bg-white/10 hover:text-white"
                }`}
              >
                <span className="text-lg">{nav.icon}</span>
                <span>{nav.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="px-6 py-4 mt-auto border-t border-white/10">
          <p className="text-xs text-gray-400 leading-relaxed">
            🔒 CareSync keeps your family's health data private and secure with local storage.
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <div className="bg-white border-b border-gray-200 px-8 py-6 flex items-center justify-between sticky top-0 z-20">
          <div>
            <h1 className="text-3xl font-serif font-bold text-navy">Family Health Hub</h1>
            <p className="text-sm text-slate mt-1">Good morning! Here's today's health overview.</p>
          </div>
          <div className="bg-mint-lt text-mint px-4 py-2 rounded-full text-sm font-semibold">
            📅 {new Date().toLocaleDateString("en-IN", { weekday: "short", month: "short", day: "numeric" })}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-8 py-6 space-y-6">
            {/* Daily Health Tip */}
            <div className="bg-gradient-to-r from-sky/10 to-mint/10 border border-sky/20 rounded-xl p-4 flex items-center gap-4 animate-fade-in">
              <span className="text-2xl">💡</span>
              <div>
                <p className="text-sm font-semibold text-navy">Daily Health Tip</p>
                <p className="text-sm text-slate mt-1">{HEALTH_TIPS[tipIndex]}</p>
              </div>
            </div>

            {/* Dashboard Page */}
            {page === "dashboard" && (
              <>
                {/* Stat Cards */}
                <div className="grid grid-cols-4 gap-4">
                  {[
                    { label: "Active Medicines", value: medicines.length, icon: "💊", color: "border-mint", bg: "from-mint-lt" },
                    { label: "Appointments", value: appointments.length, icon: "📅", color: "border-sky", bg: "from-blue-50" },
                    { label: "Low Stock Alerts", value: lowStockMeds.length, icon: "⚠️", color: "border-amber", bg: "from-amber-50" },
                    { label: "Today's Adherence", value: `${adherenceRate}%`, icon: "📊", color: "border-rose", bg: "from-rose-50" },
                  ].map((stat, i) => (
                    <div key={i} className={`bg-gradient-to-br ${stat.bg} to-white border-l-4 ${stat.color} rounded-xl p-6 shadow-card hover:shadow-card-hover transition-smooth`}>
                      <div className="text-3xl mb-2">{stat.icon}</div>
                      <div className="text-3xl font-serif font-bold text-navy">{stat.value}</div>
                      <p className="text-xs text-slate font-medium mt-2">{stat.label}</p>
                    </div>
                  ))}
                </div>

                {/* Family Members Card */}
                <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                  <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-navy flex items-center gap-2">👨‍👩‍👧‍👦 Family Members</h2>
                    <button
                      onClick={() => setModalType("addMember")}
                      className="bg-mint text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-teal-700 transition-smooth"
                    >
                      + Add Member
                    </button>
                  </div>
                  <div className="p-6">
                    <div className="flex gap-4 overflow-x-auto pb-2">
                      {members.map(member => (
                        <button
                          key={member.id}
                          onClick={() => setSelectedMember(selectedMember === member.id ? null : member.id)}
                          className={`flex-shrink-0 p-4 rounded-lg border-2 transition-smooth ${
                            selectedMember === member.id
                              ? "border-mint bg-mint-lt"
                              : "border-gray-200 bg-gray-50 hover:border-mint hover:bg-mint-lt"
                          }`}
                        >
                          <div className={`w-12 h-12 ${member.color} rounded-full flex items-center justify-center text-2xl mb-2 mx-auto`}>
                            {member.emoji}
                          </div>
                          <p className="font-semibold text-sm text-navy text-center">{member.name}</p>
                          <p className="text-xs text-slate text-center">{member.relation}, {member.age}y</p>
                        </button>
                      ))}
                    </div>
                    {selectedMember && (
                      <p className="text-xs text-mint font-semibold mt-4">
                        ✓ Filtering by: {members.find(m => m.id === selectedMember)?.name}
                        <button onClick={() => setSelectedMember(null)} className="ml-2 text-slate hover:text-navy">
                          (clear)
                        </button>
                      </p>
                    )}
                  </div>
                </div>

                {/* Today's Medicines Card */}
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                    <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                      <h2 className="text-lg font-semibold text-navy">💊 Today's Medicines</h2>
                      <button
                        onClick={() => setModalType("addMed")}
                        className="bg-mint text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-teal-700 transition-smooth"
                      >
                        + Add
                      </button>
                    </div>
                    <div className="p-6 space-y-3 max-h-96 overflow-y-auto">
                      {filteredMeds.length === 0 ? (
                        <div className="text-center py-8 text-slate">
                          <div className="text-3xl mb-2">💊</div>
                          <p>No medicines yet</p>
                        </div>
                      ) : (
                        filteredMeds.map(med => {
                          const status = medStatus[med.id];
                          const member = members.find(m => m.id === med.memberId);
                          return (
                            <div key={med.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-smooth">
                              <div className={`w-3 h-3 rounded-full flex-shrink-0 bg-${med.accentColor}`} />
                              <div className="flex-1 min-w-0">
                                <p className="font-semibold text-sm text-navy text-overflow">{med.name}</p>
                                <p className="text-xs text-slate">{med.dose} · {member?.name}</p>
                              </div>
                              <div className={`text-xs font-semibold px-2 py-1 rounded bg-${med.accentColor}-50 text-${med.accentColor}`}>
                                {med.time}
                              </div>
                              <div className="flex gap-1">
                                {!status && (
                                  <>
                                    <button
                                      onClick={() => handleMedTaken(med.id)}
                                      className="px-2 py-1 bg-mint text-white text-xs rounded font-semibold hover:bg-teal-700 transition-smooth"
                                    >
                                      ✓
                                    </button>
                                    <button
                                      onClick={() => handleMedMissed(med.id)}
                                      className="px-2 py-1 bg-rose text-white text-xs rounded font-semibold hover:bg-rose-700 transition-smooth"
                                    >
                                      ✗
                                    </button>
                                  </>
                                )}
                                {status === "taken" && (
                                  <button disabled className="px-2 py-1 bg-gray-300 text-white text-xs rounded font-semibold">
                                    ✓ Taken
                                  </button>
                                )}
                                {status === "missed" && (
                                  <button disabled className="px-2 py-1 bg-gray-300 text-white text-xs rounded font-semibold">
                                    ✗ Missed
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>

                  {/* Appointments Card */}
                  <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                    <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                      <h2 className="text-lg font-semibold text-navy">📅 Appointments</h2>
                      <button
                        onClick={() => setModalType("addApt")}
                        className="bg-mint text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-teal-700 transition-smooth"
                      >
                        + Add
                      </button>
                    </div>
                    <div className="p-6 space-y-3 max-h-96 overflow-y-auto">
                      {filteredApts.length === 0 ? (
                        <div className="text-center py-8 text-slate">
                          <div className="text-3xl mb-2">📅</div>
                          <p>No appointments</p>
                        </div>
                      ) : (
                        filteredApts.map(apt => {
                          const member = members.find(m => m.id === apt.memberId);
                          const dateObj = new Date(apt.date);
                          const day = dateObj.getDate();
                          const month = dateObj.toLocaleString("en", { month: "short" }).toUpperCase();
                          return (
                            <div key={apt.id} className={`p-3 rounded-lg ${getUrgencyStyle(apt.urgency)}`}>
                              <div className="flex gap-3">
                                <div className={`w-14 h-14 bg-${apt.urgency === "urgent" ? "rose" : apt.urgency === "upcoming" ? "sky" : "mint"} text-white rounded-lg flex flex-col items-center justify-center flex-shrink-0`}>
                                  <div className="font-serif font-bold text-lg">{day}</div>
                                  <div className="text-xs">{month}</div>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-semibold text-sm text-navy text-overflow">{apt.title}</p>
                                  <p className="text-xs text-slate">{apt.doctor}</p>
                                  <p className="text-xs text-slate">{apt.time} • {member?.name}</p>
                                  <div className={`inline-block mt-2 px-2 py-1 text-xs font-semibold rounded ${getUrgencyBadge(apt.urgency)}`}>
                                    {apt.urgency === "urgent" ? "Urgent" : apt.urgency === "upcoming" ? "Upcoming" : "Routine"}
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>

                {/* Refill Tracker & Weekly Adherence */}
                <div className="grid grid-cols-2 gap-6">
                  {/* Refill Status */}
                  <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                    <div className="border-b border-gray-200 px-6 py-4">
                      <h2 className="text-lg font-semibold text-navy">🔄 Refill Alerts</h2>
                    </div>
                    <div className="p-6 space-y-4 max-h-80 overflow-y-auto">
                      {medicines.map(med => {
                        const percent = Math.round((med.stock / med.maxStock) * 100);
                        const isLow = med.stock < 10;
                        return (
                          <div key={med.id}>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-semibold text-navy">{med.name} {isLow && "⚠️"}</span>
                              <span className={`text-xs font-semibold ${isLow ? "text-rose" : "text-mint"}`}>
                                {med.stock} / {med.maxStock}
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full transition-all ${isLow ? "bg-rose" : "bg-mint"}`}
                                style={{ width: `${percent}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Weekly Adherence */}
                  <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                    <div className="border-b border-gray-200 px-6 py-4">
                      <h2 className="text-lg font-semibold text-navy">📊 Weekly Adherence</h2>
                    </div>
                    <div className="p-6">
                      <div className="grid grid-cols-7 gap-2 mb-4">
                        {["M", "T", "W", "T", "F", "S", "S"].map((day, i) => {
                          const rates = [100, 80, 100, 60, 100, 100, 0];
                          const rate = rates[i];
                          const bgColor = rate === 100 ? "bg-mint/20" : rate > 60 ? "bg-amber/20" : rate > 0 ? "bg-rose/20" : "bg-gray-100";
                          const textColor = rate === 100 ? "text-mint" : rate > 60 ? "text-amber" : rate > 0 ? "text-rose" : "text-slate";
                          return (
                            <div key={i} className="text-center">
                              <div className="text-xs font-semibold text-slate mb-1">{day}</div>
                              <div className={`${bgColor} ${textColor} aspect-square rounded-lg flex items-center justify-center font-semibold text-xs`}>
                                {rate > 0 ? `${rate}%` : "–"}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="bg-mint-lt rounded-lg p-3">
                        <p className="text-sm font-semibold text-mint">🎯 Great job! Average adherence: 91%</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Emergency Contacts */}
                <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                  <div className="border-b border-gray-200 px-6 py-4">
                    <h2 className="text-lg font-semibold text-navy">🚨 Emergency Contacts</h2>
                  </div>
                  <div className="p-6">
                    <div className="grid grid-cols-4 gap-4">
                      {EMERGENCY_CONTACTS.map((contact, i) => (
                        <a key={i} href={contact.phone} className="no-underline">
                          <button className={`w-full ${contact.bg} ${contact.color} py-6 rounded-xl hover:shadow-lg transition-smooth flex flex-col items-center gap-2`}>
                            <span className="text-3xl">{contact.icon}</span>
                            <span className="font-semibold text-sm text-center">{contact.name}</span>
                          </button>
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Medicines Page */}
            {page === "medicines" && (
              <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-navy">💊 All Medicines</h2>
                  <button
                    onClick={() => setModalType("addMed")}
                    className="bg-mint text-white px-4 py-2 rounded-lg font-semibold hover:bg-teal-700 transition-smooth"
                  >
                    + Add Medicine
                  </button>
                </div>
                <div className="p-6 space-y-3">
                  {medicines.length === 0 ? (
                    <div className="text-center py-12 text-slate">
                      <div className="text-4xl mb-2">💊</div>
                      <p>No medicines added yet</p>
                    </div>
                  ) : (
                    medicines.map(med => {
                      const status = medStatus[med.id];
                      const member = members.find(m => m.id === med.memberId);
                      return (
                        <div key={med.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-smooth">
                          <div className={`w-4 h-4 rounded-full flex-shrink-0 bg-${med.accentColor}`} />
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-navy text-overflow">{med.name}</p>
                            <p className="text-sm text-slate">{med.dose} · {med.freq} · 👤 {member?.name}</p>
                          </div>
                          <div className={`text-sm font-semibold px-3 py-1 rounded bg-${med.accentColor}-50 text-${med.accentColor}`}>
                            {med.time}
                          </div>
                          <div className="flex gap-2">
                            {!status && (
                              <>
                                <button
                                  onClick={() => handleMedTaken(med.id)}
                                  className="px-3 py-2 bg-mint text-white rounded font-semibold hover:bg-teal-700 transition-smooth"
                                >
                                  ✓ Taken
                                </button>
                                <button
                                  onClick={() => handleMedMissed(med.id)}
                                  className="px-3 py-2 bg-rose text-white rounded font-semibold hover:bg-rose-700 transition-smooth"
                                >
                                  ✗ Missed
                                </button>
                              </>
                            )}
                            {status === "taken" && (
                              <button disabled className="px-3 py-2 bg-gray-300 text-white rounded font-semibold">
                                ✓ Taken
                              </button>
                            )}
                            {status === "missed" && (
                              <button disabled className="px-3 py-2 bg-gray-300 text-white rounded font-semibold">
                                ✗ Missed
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* Appointments Page */}
            {page === "appointments" && (
              <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-navy">📅 Doctor Appointments</h2>
                  <button
                    onClick={() => setModalType("addApt")}
                    className="bg-mint text-white px-4 py-2 rounded-lg font-semibold hover:bg-teal-700 transition-smooth"
                  >
                    + Schedule
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  {appointments.length === 0 ? (
                    <div className="text-center py-12 text-slate">
                      <div className="text-4xl mb-2">📅</div>
                      <p>No appointments scheduled</p>
                    </div>
                  ) : (
                    appointments.map(apt => {
                      const member = members.find(m => m.id === apt.memberId);
                      const dateObj = new Date(apt.date);
                      const day = dateObj.getDate();
                      const month = dateObj.toLocaleString("en", { month: "short" }).toUpperCase();
                      return (
                        <div key={apt.id} className={`p-4 rounded-lg ${getUrgencyStyle(apt.urgency)}`}>
                          <div className="flex gap-4">
                            <div className={`w-16 h-16 bg-${apt.urgency === "urgent" ? "rose" : apt.urgency === "upcoming" ? "sky" : "mint"} text-white rounded-lg flex flex-col items-center justify-center flex-shrink-0`}>
                              <div className="font-serif font-bold text-xl">{day}</div>
                              <div className="text-xs">{month}</div>
                            </div>
                            <div className="flex-1">
                              <p className="font-semibold text-navy text-lg">{apt.title}</p>
                              <p className="text-slate">{apt.doctor}</p>
                              <p className="text-sm text-slate">{apt.time} • 👤 {member?.name}</p>
                              <div className={`inline-block mt-2 px-3 py-1 text-sm font-semibold rounded ${getUrgencyBadge(apt.urgency)}`}>
                                {apt.urgency === "urgent" ? "Urgent" : apt.urgency === "upcoming" ? "Upcoming" : "Routine"}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* Refills Page */}
            {page === "refills" && (
              <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                <div className="border-b border-gray-200 px-6 py-4">
                  <h2 className="text-xl font-semibold text-navy">🔄 Prescription Refill Tracker</h2>
                </div>
                <div className="p-6">
                  {lowStockMeds.length > 0 && (
                    <div className="bg-rose-50 border border-rose/20 rounded-lg p-4 mb-6 flex gap-3">
                      <span className="text-2xl flex-shrink-0">⚠️</span>
                      <div>
                        <p className="font-semibold text-rose">Low Stock Alert</p>
                        <p className="text-sm text-slate mt-1">
                          {lowStockMeds.map(m => m.name).join(", ")} need refilling soon.
                        </p>
                      </div>
                    </div>
                  )}
                  <div className="space-y-4">
                    {medicines.map(med => {
                      const percent = Math.round((med.stock / med.maxStock) * 100);
                      const isLow = med.stock < 10;
                      const member = members.find(m => m.id === med.memberId);
                      return (
                        <div
                          key={med.id}
                          className={`p-4 rounded-lg border-l-4 ${isLow ? "border-rose/50 bg-rose-50" : "border-mint/50 bg-mint-lt/30"}`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <p className="font-semibold text-navy">{med.name} {isLow && "⚠️"}</p>
                              <p className="text-sm text-slate">👤 {member?.name} · {med.dose}</p>
                            </div>
                            <div className="text-right">
                              <p className={`font-semibold ${isLow ? "text-rose" : "text-mint"}`}>
                                {med.stock} / {med.maxStock}
                              </p>
                              {isLow && <p className="text-xs text-rose font-semibold">Refill Now!</p>}
                            </div>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full transition-all ${isLow ? "bg-rose" : "bg-mint"}`}
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Emergency Page */}
            {page === "emergency" && (
              <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                <div className="border-b border-gray-200 px-6 py-4">
                  <h2 className="text-xl font-semibold text-navy">🚨 Emergency Contacts</h2>
                </div>
                <div className="p-6 space-y-6">
                  <div className="bg-rose-50 border border-rose/20 rounded-lg p-4">
                    <p className="font-semibold text-rose">⚠️ In life-threatening emergencies, call 108 immediately.</p>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    {EMERGENCY_CONTACTS.map((contact, i) => (
                      <a key={i} href={contact.phone} className="no-underline">
                        <button className={`w-full ${contact.bg} ${contact.color} py-8 rounded-2xl hover:shadow-lg transition-smooth flex flex-col items-center gap-3`}>
                          <span className="text-5xl">{contact.icon}</span>
                          <span className="font-semibold text-lg text-center">{contact.name}</span>
                          <span className="text-xs opacity-75">Tap to call</span>
                        </button>
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Modals */}
      {modalType && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm animate-fade-in" onClick={() => setModalType(null)}>
          <div className="bg-white rounded-2xl p-8 w-96 shadow-2xl animate-slide-down" onClick={e => e.stopPropagation()}>
            {modalType === "addMed" && (
              <>
                <h3 className="text-2xl font-serif font-bold text-navy mb-6">💊 Add Medicine</h3>
                <div className="space-y-4">
                  <select
                    value={formMed.memberId}
                    onChange={e => setFormMed(prev => ({ ...prev, memberId: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                  >
                    {members.map(m => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                  <input
                    placeholder="Medicine name"
                    value={formMed.name}
                    onChange={e => setFormMed(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      placeholder="Dosage (e.g. 500mg)"
                      value={formMed.dose}
                      onChange={e => setFormMed(prev => ({ ...prev, dose: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                    <input
                      type="time"
                      value={formMed.time}
                      onChange={e => setFormMed(prev => ({ ...prev, time: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <select
                      value={formMed.freq}
                      onChange={e => setFormMed(prev => ({ ...prev, freq: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    >
                      <option>Once daily</option>
                      <option>Twice daily</option>
                      <option>Thrice daily</option>
                      <option>Weekly</option>
                    </select>
                    <input
                      type="number"
                      placeholder="Stock"
                      value={formMed.stock}
                      onChange={e => setFormMed(prev => ({ ...prev, stock: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setModalType(null)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-navy font-semibold hover:bg-gray-50 transition-smooth"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={addMedicine}
                    className="flex-1 px-4 py-2 bg-mint text-white rounded-lg font-semibold hover:bg-teal-700 transition-smooth"
                  >
                    Add Medicine
                  </button>
                </div>
              </>
            )}

            {modalType === "addApt" && (
              <>
                <h3 className="text-2xl font-serif font-bold text-navy mb-6">📅 Add Appointment</h3>
                <div className="space-y-4">
                  <select
                    value={formApt.memberId}
                    onChange={e => setFormApt(prev => ({ ...prev, memberId: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                  >
                    {members.map(m => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                  <input
                    placeholder="Appointment title"
                    value={formApt.title}
                    onChange={e => setFormApt(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                  />
                  <input
                    placeholder="Doctor name"
                    value={formApt.doctor}
                    onChange={e => setFormApt(prev => ({ ...prev, doctor: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="date"
                      value={formApt.date}
                      onChange={e => setFormApt(prev => ({ ...prev, date: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                    <input
                      type="time"
                      value={formApt.time}
                      onChange={e => setFormApt(prev => ({ ...prev, time: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setModalType(null)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-navy font-semibold hover:bg-gray-50 transition-smooth"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={addAppointment}
                    className="flex-1 px-4 py-2 bg-mint text-white rounded-lg font-semibold hover:bg-teal-700 transition-smooth"
                  >
                    Schedule
                  </button>
                </div>
              </>
            )}

            {modalType === "addMember" && (
              <>
                <h3 className="text-2xl font-serif font-bold text-navy mb-6">👨‍👩‍👧 Add Family Member</h3>
                <div className="space-y-4">
                  <input
                    placeholder="Name"
                    value={formMember.name}
                    onChange={e => setFormMember(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="number"
                      placeholder="Age"
                      value={formMember.age}
                      onChange={e => setFormMember(prev => ({ ...prev, age: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                    <input
                      placeholder="Relation"
                      value={formMember.relation}
                      onChange={e => setFormMember(prev => ({ ...prev, relation: e.target.value }))}
                      className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-mint"
                    />
                  </div>
                </div>
                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setModalType(null)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-navy font-semibold hover:bg-gray-50 transition-smooth"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={addMember}
                    className="flex-1 px-4 py-2 bg-mint text-white rounded-lg font-semibold hover:bg-teal-700 transition-smooth"
                  >
                    Add Member
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      {toast && (
        <div className="fixed bottom-6 right-6 bg-navy text-white px-6 py-3 rounded-lg shadow-2xl animate-slide-up flex items-center gap-3 max-w-xs z-50">
          <span className="text-xl">{toast.type === "error" ? "❌" : "✅"}</span>
          <p className="text-sm font-medium">{toast.message}</p>
        </div>
      )}
    </div>
  );
}
